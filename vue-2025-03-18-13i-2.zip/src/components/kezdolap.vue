<script setup>

</script>

<template>
<h1>Főoldal</h1>

</template>

<style scoped>

</style>
