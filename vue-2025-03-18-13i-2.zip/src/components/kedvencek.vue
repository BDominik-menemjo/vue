<script setup>

</script>

<template>
<h1>Kedvencek</h1>
</template>

<style scoped>

</style>
