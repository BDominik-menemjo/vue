<script setup>
  import Repter from './components/Repter.vue'
</script>

<template>
  <h1>Airport App!</h1>
  <Repter />
</template>

<style scoped>

</style>
