<script setup>

</script>
<template>
    <nav class="d-flex justify-content-center">
        <router-link to="/" class="p-3">Kezdőlap</router-link>
        <router-link to="/Favorites" class="p-3">Kedvencek</router-link>
    </nav>
</template>