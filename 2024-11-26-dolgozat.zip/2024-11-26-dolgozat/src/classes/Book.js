export default class Book{
    #azon;
    #name;
    #author;
}