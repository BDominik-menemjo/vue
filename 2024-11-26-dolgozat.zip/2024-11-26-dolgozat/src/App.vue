<script setup>
import Books from './components/Books.vue'
import Cart from './components/Cart.vue'
</script>

<template>
  <Books />
  <Cart />
</template>

<style scoped>
  
</style>
