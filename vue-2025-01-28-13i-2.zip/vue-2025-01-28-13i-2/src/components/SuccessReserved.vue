<script setup>

</script>

<template>
 <section>
        <h2>Success</h2>
    </section>
</template>

<style scoped>

</style>
