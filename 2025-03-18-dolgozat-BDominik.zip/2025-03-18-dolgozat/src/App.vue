<script setup>
import PasswordInput from "./components/PasswordInput.vue"
</script>

<template>
  <PasswordInput />
</template>

<style scoped>

</style>
