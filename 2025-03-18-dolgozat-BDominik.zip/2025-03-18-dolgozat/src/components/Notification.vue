<script setup>
    import {defineProps} from "vue";

    const props=defineProps({
        message: String
    })
</script>

<template>
    <p></p>
</template>

<style scoped>

</style>
