<script setup>
import EventRegistration from './components/EventRegistration.vue'
</script>

<template>
  <h1>Event Registration App</h1>
  <EventRegistration />
</template>
  
<style scoped>

</style>
