<script setup>
import Quiz from './components/Quiz.vue'
</script>

<template>
  <header>
    <h1>Quiz</h1>
  </header>
  <main>
    <Quiz />
  </main>
</template>

<style scoped>
  
</style>
