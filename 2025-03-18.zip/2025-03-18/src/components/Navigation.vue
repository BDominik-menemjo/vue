<script setup>

</script>

<template>
<header>
    <p class="text-center"><img src="../assets/pokeapi_256.png" alt=""></p>
    <nav class="d-flex justify-content-center">
        <router-link to="/" class="p-3">Kezdőlap</router-link>
        <router-link to="/kedvencek" class="p-3">Kedvencek</router-link>
    </nav>
  </header>
</template>

<style scoped>

</style>
