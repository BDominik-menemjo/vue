<script setup>
import Navigation from "./components/Navigation.vue";
</script>

<template>
  <Navigation />
  <router-view />
</template>

<style scoped></style>
