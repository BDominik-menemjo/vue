<script setup>
import axios from 'axios';
import Diak from './classes/Diak.js';
import { ref } from 'vue';

const SOR=5;
const OSZLOP=5;

const ulesrend = ref(new Array(SOR).fill(null).map(()=>Array(OSZLOP).fill(null)));

const setUlesrend=()=>{
  for(let i=0, i<ulesrend.value.length)
}
</script>

<template>
  <main>
    <section>
      <h1>Ülésrend</h1>
      <div class="rows df" v-for="(sor, i) in ulesrend">
        <div class="cols" v-for="(oszlop, j) in sor">
          <div>A</div>
        </div>
      </div>
    </section>
  </main>
</template>

<style scoped>
h1, .df div{
  text-align: center;
}
.df{
  display: flex;
  justify-content: space-evenly;
  align-items: center;
}
.df div{
  width: 200px;
  padding-top: 20px;
  background-color: aqua;
  color: #000;
  font-weight: 600;
  cursor: pointer;
}
.df div:hover{
  background-color: antiquewhite;
}
.cols{
  margin: 20px;
}
</style>
