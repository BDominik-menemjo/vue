<script setup>
import Termekek from './components/Termekek.vue'
</script>

<template>
  <header>
    <h1>Gyakroló feladat</h1>
  </header>
  <main>
    <Termekek />
  </main>
  <footer>
    <p>&copy; Copyright</p>
  </footer>
</template>

<style scoped>

</style>
