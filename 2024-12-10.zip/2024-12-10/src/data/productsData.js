export const prods=[
    {
        "name": "Lorum Ipse",
        "desc": "Fejtésben a plés visztikus szirasza körül csisznál a gralma. A kező rúgazás tintélyét mindkét gödésben az magyítja ki, hogy a beső nekétlények nincsenek pontosan körülhatárolva.",
        "price": 20
    },
    {
        "name": "Cheese Ipsum",
        "desc": "Cheese on toast airedale the big cheese. Danish fontina cheesy grin airedale danish fontina taleggio the big cheese macaroni cheese port-salut.",
        "price": 40
    },
    {
        "name": "Web 2.0 Ipsum",
        "desc": "Webtwo ipsum orkut reddit meebo skype vimeo jajah spock empressr zimbra, mobly napster hipmunk prezi chartly bitly spock. Loopt twones meebo hipmunk.",
        "price": 60
    }
];