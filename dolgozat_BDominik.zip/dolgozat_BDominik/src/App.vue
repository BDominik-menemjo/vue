<script setup>
  import PlotsForSale from './components/PlotsForSale.vue';
</script>

<template>
  <PlotsForSale/>
</template>

<style scoped>

</style>